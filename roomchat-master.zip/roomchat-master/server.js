const express = require('express');
//const { Socket } = require('socket.io');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const onlineUser = {}
const groupChat = {}

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html')
});

io.on('connection', (socket) => {
    console.log('a user connected', socket.id);
    socket.on('joinRoom', (roomSocketIds) => {
        console.log('joinRoom :: socket :: room ::', socket.room);
        console.log('joinRoom :: roomSocketIds ::', roomSocketIds);
        const socketIds = JSON.parse(roomSocketIds);
        console.log('joinRoom :: socketIds ::', socketIds);
        if (socket.room) {
            socket.leave(socket.room);
        }
        socket.room = parseInt(Math.random() * 36);
        console.log('joinRoom :: socket :: generate :: room ::', socket.room);
        socket.join(socket.room);
        io.to(socketIds.oppSocketId).emit('reqJoinRoom', { room: socket.room });
    });
    socket.on('reqJoinRoom', (room) => {
        console.log('reqJoinRoom :: socket :: room ::', socket.room);
        const roomObj = JSON.parse(room);
        console.log('reqJoinRoom :: roomObj ::', roomObj);
        if (socket.room) {
            socket.leave(socket.room);
        }
        socket.room = roomObj.room;
        socket.join(socket.room);
    });
    socket.on('chatMessage', (msg) => {
        const playLoad = JSON.parse(msg)
        console.log('chatMessage :: playLoad: ', playLoad, playLoad.socketId, playLoad.message);
        console.log('chatMessage :: socket :: room ::', socket.room);
        if (socket.room) {
            io.to(socket.room).emit('chatMessage1', playLoad.message)
        }
        // io.to(playLoad.socketId).emit('chat message1',playLoad.message)
        // socket.emit('chat message1',playLoad.message)
    });
    socket.on('userName', (user) => {
        console.log("onlineUser1", onlineUser)
        onlineUser[user] = socket.id
        console.log("onlineUser2", onlineUser)
        console.log('userOnline: ' + user);
        io.emit('onlineUser', onlineUser)
    });
    // socket.on('base64 file', function (msg) {
    //     console.log('received base64 file from' + msg.username);
    //     socket.username = msg.username;
    //     // socket.broadcast.emit('base64 image', //exclude sender
    //     io.sockets.emit('base64 file',  //include sender

    //         {
    //             username: socket.username,
    //             file: msg.file,
    //             fileName: msg.fileName
    //         }

    //     );
    // });

    socket.on('disconnect', () => {
        console.log("disconnet onlineUser1", onlineUser)
        console.log('user disconnected', socket.id)
        for (x in onlineUser) {
            console.log("x :", onlineUser[x])
            if (onlineUser[x] == socket.id) {
                delete onlineUser[x]
            }
        }
        console.log("onlineUser1", onlineUser)
        io.emit('onlineUser', onlineUser)
    });
});

http.listen(2000, () => {
    console.log('server list on 2000 port')
});